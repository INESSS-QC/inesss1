## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = FALSE
)

## ----setup, message=FALSE, warning=FALSE--------------------------------------
### Packages
library(inesss)
library(lubridate)
library(data.table)
library(kableExtra)
library(readxl)


## ---- echo=TRUE---------------------------------------------------------------
ID = 'ID'
DATE_INDEX = 'DATE_INDEX'
Dx_table = 'Combine_Dx_CCI_INSPQ18'
CIM = c('CIM9', 'CIM10')
scores = 'CCI_INSPQ_2018_CIM10'
lookup = 2
n1 = 30; n2 = 730
dt_source = c('V_DIAGN_SEJ_HOSP_CM',
              'V_SEJ_SERV_HOSP_CM',
              'V_EPISO_SOIN_DURG_CM',
              'I_SMOD_SERV_MD_CM')
dt_desc = list(V_DIAGN_SEJ_HOSP_CM = 'MEDECHO',
               V_SEJ_SERV_HOSP_CM = 'MEDECHO',
               V_EPISO_SOIN_DURG_CM = 'BDCU',
               I_SMOD_SERV_MD_CM = 'SMOD')
confirm_sourc = list(MEDECHO = 1,
                     BDCU = 2,
                     SMOD = 2)
obstetric_exclu = TRUE
exclu_diagn = c('drug', 'ld')
keep_confirm_data = TRUE

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`1-unique`
dt[]

## -----------------------------------------------------------------------------
### Arranger dataset
if (!is.data.table(dt)) {  # convertir data.table
  dt <- setDT(dt)
}
dt <- dt[, c(ID, DATE_INDEX), with = FALSE]  # sélection des colonnes
setnames(dt, names(dt), c("ID", "DATE_INDEX"))  # renommer les colonnes
setkey(dt)  # tri ID+DATE_INDEX
if (!lubridate::is.Date(dt$DATE_INDEX)) {  # Convertir au format DATE la colonne DATE_INDEX
  dt[, DATE_INDEX := lubridate::as_date(DATE_INDEX)]
}
dt <- dt[complete.cases(dt)]  # Supprimer les NAs
# Conserver la première date index de chaque ID s'ils ne sont pas unique
idx <- rmNA(dt[, .I[.N > 1], .(ID)]$V1)
if (length(idx)) {
  dt <- dt[dt[, .I[1], .(ID)]$V1]
}

### Cohorte d'étude
cohort <- dt$ID
dt[]

## -----------------------------------------------------------------------------
Dx_table <- inesss:::SQL_comorbidity_diagn.select_Dx_table(Dx_table)
Dx_table[1:3]

## -----------------------------------------------------------------------------
names(Dx_table)

## -----------------------------------------------------------------------------
# Exclusion des diagnostiques
if (!is.null(exclu_diagn)) {
  Dx_table <- Dx_table[!names(Dx_table) %in% exclu_diagn]
}
names(Dx_table)

## -----------------------------------------------------------------------------
# CIM9 vs CIM10 -- Filtrer les types de codes si on veut seulement une version
# de classification de code.
if (length(CIM) == 1) {
  for (i in names(Dx_table)) {
    Dx_table[[i]] <- Dx_table[[i]][[CIM]]  # conserver seulement CIM9 ou CIM10
  }
} else {
  for (i in names(Dx_table)) {
    Dx_table[[i]] <- unlist(Dx_table[[i]], use.names = FALSE)  # grouper CIM9 et CIM10 en un seul vecteur
  }
}
Dx_table[1:3]

## -----------------------------------------------------------------------------
dt[]

## -----------------------------------------------------------------------------
dt[]

## -----------------------------------------------------------------------------
DIAGN <- inesss:::vignettes_datas$SQL_comorbidity$`2-filtDx`
DIAGN[]

## -----------------------------------------------------------------------------
### Filtrer dt pour en faire l'analyse
# Supprimer les diagnostics qui sont pas dans l'intervalle [DATE_INDEX - lookup - n1; DATE_INDEX]
dt <- DIAGN[dt, on = .(ID), nomatch = 0]  # ajouter les diagn aux dates index en conservant seulement les id présent dans DIAGN et dt
dt <- dt[DATE_INDEX %m-% months(lookup*12) - n2 <= DATE_DX & DATE_DX <= DATE_INDEX]  # [index-X{ans}-n2{jours}; index]
setkey(dt, ID, DIAGN, DATE_DX)
# Supprimer les dates < (DATE_INDEX - lookup) dont la source a une confirmation = 1
sourc <- inesss:::comorbidity.confirm_sourc_names(confirm_sourc, 1)
if (length(sourc)) {
  idx <- intersect(
    dt[, .I[SOURCE %in% sourc]],
    dt[, .I[DATE_DX < DATE_INDEX %m-% months(lookup*12)]]
  )
  if (length(idx)) {
    dt <- dt[!idx]
  }
}
dt[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`3.1-Obstetric`
dt[]

## -----------------------------------------------------------------------------
dt_gross <- inesss:::vignettes_datas$SQL_comorbidity$`3.2-Obstetric`
dt_gross[]

## -----------------------------------------------------------------------------
dt_diab_hyp <- unique(dt[  # un seul cas par ID + DIAGN + DATE
  DIAGN %in% c("diab", "diabwc", "hyp"),  # cas de diabète ou d'hypertension
  .(ID, DATE_DX, DIAGN)  # colonnes
])
dt_gross <- unique(dt_gross[, .(ID, DATE_OBSTE = DATE_DX)])  # un seul cas par ID + DATE
dt_diab_hyp <- dt_gross[dt_diab_hyp, on = .(ID), nomatch = 0]  # combinaison {diab, hyp} + {obstetric}
dt_diab_hyp <- dt_diab_hyp[  # supprimer les diagn qui ont au moins un cas de grossesse [-120; 180] jours.
  !is.na(DATE_OBSTE) &  # n'a pas de cas de grosseses
    DATE_OBSTE + 180 >= DATE_DX & DATE_DX >= DATE_OBSTE - 120  # cas où l'obstetric annule le diab ou l'hyp
]
dt_diab_hyp <- unique(dt_diab_hyp[, .(ID, DATE_DX, DIAGN)])  # un seul cas par date et diagn
dt <- dt[!dt_diab_hyp, on = .(ID, DATE_DX, DIAGN)]  # exclure de dt les observations qui sont présentes dans dt_diab_hyp
dt[]

## -----------------------------------------------------------------------------
Obstetrics_Dx$obstetric

## ---- echo=TRUE---------------------------------------------------------------
confirm_sourc = list(MEDECHO = 1, BDCU = 2, SMOD = 2)

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`4-priorSourc`
dt[]

## -----------------------------------------------------------------------------
for (desc in names(confirm_sourc)) {  # Trier les données selon l'importance des sources
  dt[SOURCE == desc, tri := confirm_sourc[[desc]]]
}
setkey(dt, ID, DIAGN, DATE_DX, tri, SOURCE)
dt[, tri := NULL]
dt[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`5-filtConfirm`
dt[]

## -----------------------------------------------------------------------------
dt[, row := 1:nrow(dt)]
dates_b4 <- dt[DATE_DX < DATE_INDEX %m-% months(lookup*12)]
if (nrow(dates_b4)) {
  dates_after <- dt[DATE_DX >= DATE_INDEX %m-% months(lookup*12), .(ID, DATE_DX2 = DATE_DX, DIAGN, row2 = row)]
  dates_b4 <- dates_after[dates_b4, on = .(ID, DIAGN), allow.cartesian = TRUE, nomatch = 0]
  dates_b4 <- dates_b4[DATE_DX + n2 >= DATE_DX2]
  dates_b4[, confirm := DATE_DX2 - DATE_DX]
  dates_b4 <- dates_b4[n1 <= confirm & confirm <= n2]
  if (nrow(dates_b4)) {
    dates_b4 <- dates_b4[dates_b4[, .I[1], .(ID, DIAGN)]$V1]
    dt <- dt[sunique(c(dates_after$row2, dates_b4$row))]
    dt[, row := NULL]
  }
}
dt[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`6.1-conf`
dt[]

## -----------------------------------------------------------------------------
dt[, DATE_DX := as.integer(DATE_DX)]
dt <- inesss:::comorbidity.confirm_diagn(dt, n1, n2, confirm_sourc)
dt[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`6.2-conf`
dt[]

## -----------------------------------------------------------------------------
dt[, DATE_DX := as.integer(DATE_DX)]
dt <- inesss:::comorbidity.confirm_diagn(dt, n1, n2, confirm_sourc)
dt[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`6.3-conf`
dt[]

## -----------------------------------------------------------------------------
dt[, DATE_DX := as.integer(DATE_DX)]
dt <- inesss:::comorbidity.confirm_diagn(dt, n1, n2, confirm_sourc)
dt[]

## -----------------------------------------------------------------------------
dt[DIAGN == "diab", DIAGN := "aids"]
dt[DIAGN == "hyp", DIAGN := "metacanc"]
dt[DIAGN == "diabwc", DIAGN := "fed"]
dt[]

## -----------------------------------------------------------------------------
ComorbidityWeights$CCI_INSPQ_2018_CIM10

## -----------------------------------------------------------------------------
dt <- inesss::ComorbidityWeights[[scores]][, .(DIAGN = DIAGN_CODE, POIDS)][dt, on = .(DIAGN)]
dt[]

## -----------------------------------------------------------------------------
dt <- dcast(dt, ID ~ DIAGN, value.var = "POIDS")
dt <- inesss:::replace_NA_in_dt(dt, 0L)
dt[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`8-nDx`
dt[]

## -----------------------------------------------------------------------------
Dx_par_id <- dt[, .(nDx = .N), .(ID)]
Dx_par_id[]

## -----------------------------------------------------------------------------
dt <- inesss:::vignettes_datas$SQL_comorbidity$`7-poids`
dt[]

## -----------------------------------------------------------------------------
Dx_table_name <- "Combine_Dx_CCI_INSPQ18"  # argument nécessaire

### Ajouter les colonnes manquantes - sauf exclusions
cols <- names(Dx_table)
if (!is.null(exclu_diagn)) {
  cols <- cols[!cols %in% exclu_diagn]
}
for (col in cols) {
  if (!col %in% names(dt)) {
    dt[, (col) := 0L]
  }
}

### Calcul du score
if (Dx_table_name == "Combine_Dx_CCI_INSPQ18") {
  charl_cols <- names(inesss::Charlson_Dx_CCI_INSPQ18)
  elix_cols <- names(inesss::Elixhauser_Dx_CCI_INSPQ18)
  comb_cols <- names(inesss::Combine_Dx_CCI_INSPQ18)
  if (!is.null(exclu_diagn)) {
    charl_cols <- charl_cols[!charl_cols %in% exclu_diagn]
    elix_cols <- elix_cols[!elix_cols %in% exclu_diagn]
    comb_cols <- comb_cols[!comb_cols %in% exclu_diagn]
  }
  dt[, Charlson_Dx_CCI_INSPQ18 := rowSums(dt[, charl_cols, with = FALSE])]
  dt[, Elixhauser_Dx_CCI_INSPQ18 := rowSums(dt[, elix_cols, with = FALSE])]
  dt[, Combine_Dx_CCI_INSPQ18 := rowSums(dt[, comb_cols, with = FALSE])]
  setcolorder(dt, c("ID", "Combine_Dx_CCI_INSPQ18", "Charlson_Dx_CCI_INSPQ18", "Elixhauser_Dx_CCI_INSPQ18", cols))
} else {
  score_cols <- names(Dx_table)
  if (is.null(exclu_diagn)) {
    score_cols <- score_cols[!score_cols %in% exclu_diagn]
  }
  dt[, (Dx_table_name) := rowSums(dt[, score_cols, with = FALSE])]
  setcolorder(dt, c("ID", Dx_table_name, cols))
}

dt[]

## -----------------------------------------------------------------------------
cols <- names(dt)
dt[, nDx := 6]
setcolorder(dt, c(cols[1], "nDx", cols[2:34]))
dt[]

## -----------------------------------------------------------------------------
cohort <- 1:3
ids_2_add <- cohort[!cohort %in% dt$ID]
if (length(ids_2_add)) {
  dt <- rbind(dt, data.table(ID = ids_2_add), fill = TRUE)
  # Remplacer les NA par 0
  for (col in names(dt)[names(dt) != "ID"]) {
    set(dt, which(is.na(dt[[col]])), col, 0L)
  }
}
setkey(dt, ID)
dt[]

