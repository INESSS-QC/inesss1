## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  eval = TRUE
)

## ----setup, echo=FALSE--------------------------------------------------------
library(inesss)
library(data.table)

## ---- echo=FALSE--------------------------------------------------------------
DT <- data.table(
  ID = 1L,
  DATE_DX = c("2020-01-01", "2020-01-05", "2020-01-10", "2020-01-11",
              "2020-01-15", "2020-01-20", "2020-02-09", "2020-02-10"),
  DIAGN = c(rep("cancer", 4), rep("cancermeta", 4))
)

## -----------------------------------------------------------------------------
print(DT)

## -----------------------------------------------------------------------------
dt1 <- confirm_2Dx(dt = DT, ID = "ID", DATE = "DATE_DX", DIAGN = NULL,
                  study_start = NULL, study_end = NULL,
                  n1 = 10, n2 = 20,
                  keep_first = FALSE, reverse = FALSE)
print(dt1)

## -----------------------------------------------------------------------------
dt2 <- confirm_2Dx(dt = DT, ID = "ID", DATE = "DATE_DX", DIAGN = "DIAGN",
                  study_start = NULL, study_end = NULL,
                  n1 = 10, n2 = 20,
                  keep_first = FALSE, reverse = FALSE)
print(dt2)

## -----------------------------------------------------------------------------
dt3 <- confirm_2Dx(dt = DT, ID = "ID", DATE = "DATE_DX", DIAGN = NULL,
                  study_start = "2020-01-10", study_end = "2020-01-20",
                  n1 = 10, n2 = 20,
                  keep_first = FALSE, reverse = FALSE)
print(dt3)

## -----------------------------------------------------------------------------
dt4 <- confirm_2Dx(dt = DT, ID = "ID", DATE = "DATE_DX", DIAGN = NULL,
                  study_start = NULL, study_end = NULL,
                  n1 = 10, n2 = 20,
                  keep_first = TRUE, reverse = FALSE)
print(dt4)

## -----------------------------------------------------------------------------
dt5 <- confirm_2Dx(dt = DT, ID = "ID", DATE = "DATE_DX", DIAGN = NULL,
                  study_start = NULL, study_end = NULL,
                  n1 = 10, n2 = 20,
                  keep_first = FALSE, reverse = TRUE)
print(dt5)

