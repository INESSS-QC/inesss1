## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  eval = FALSE
)

## ----setup, echo=FALSE, eval=TRUE---------------------------------------------
library(inesss)

## ---- eval=FALSE--------------------------------------------------------------
#  SQL_diagn(
#    conn = SQL_connexion(),
#    cohort = NULL,
#    debut,
#    fin,
#    Dx_table,
#    CIM = c('CIM9', 'CIM10'),
#    dt_source = c('V_DIAGN_SEJ_HOSP_CM',
#                  'V_SEJ_SERV_HOSP_CM',
#                  'V_EPISO_SOIN_DURG_CM',
#                  'I_SMOD_SERV_MD_CM'),
#    dt_desc = list(V_DIAGN_SEJ_HOSP_CM = 'MEDECHO',
#                   V_SEJ_SERV_HOSP_CM = 'MEDECHO',
#                   V_EPISO_SOIN_DURG_CM = 'BDCU',
#                   I_SMOD_SERV_MD_CM = 'SMOD'),
#    date_dx_var = 'admis',
#    typ_diagn = c('A', 'P', 'S', 'D'),
#    exclu_diagn = NULL,
#    verbose = TRUE
#  )

## ---- eval=FALSE--------------------------------------------------------------
#  debut = '2018-01-01'
#  fin = '2020-12-31'
#  Dx_table = list(Infarctus = list(CIM9 = c("410%", "411%", "412%", "413%", "414%"),
#                                   CIM10 = c("I21%", "I22%", "I23%", "I24%", "I25%")))

## ---- eval=FALSE, echo=FALSE--------------------------------------------------
#  cat(query_I_SMOD_SERV_MD_CM(debut, fin, unlist(Dx_table$Infarctus)),
#      sep = "")

## ---- eval=FALSE, echo=FALSE--------------------------------------------------
#  cat(query_V_DIAGN_SEJ_HOSP_CM(debut, fin, Dx_table$Infarctus),
#      sep = "")

## ---- eval=FALSE, echo=FALSE--------------------------------------------------
#  cat(query_V_EPISO_SOIN_DURG_CM(debut, fin, unlist(Dx_table$Infarctus), "admis"),
#      sep = "")

## ---- eval=FALSE, echo=FALSE--------------------------------------------------
#  cat(query_V_SEJ_SERV_HOSP_CM(debut, fin, unlist(Dx_table$Infarctus), "admis"),
#      sep = "")

## -----------------------------------------------------------------------------
#  # CIM10 seulement
#  Dx_table = list(Infarctus = list(CIM10 = c("I21%", "I22%", "I23%", "I24%", "I25%")))
#  # Date du diagnostic = Date de départ
#  date_dx_var = "depar"
#  # Aucun critère sur les types de diagnostics
#  typ_diagn = NULL

## ---- eval=FALSE, echo=FALSE--------------------------------------------------
#  cat(query_V_DIAGN_SEJ_HOSP_CM(debut, fin, Dx_table$Infarctus, date_dx_var, typ_diagn),
#      sep = "")

