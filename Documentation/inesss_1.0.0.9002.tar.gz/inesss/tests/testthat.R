library(testthat)
library(inesss)

test_check("inesss")
