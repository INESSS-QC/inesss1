#' Addin
#'
#' @return \link{formulaire}
#' @keywords internal
#' @encoding UTF-8
formulaire_addin <- function() {
  return(inesss:::formulaire())
}
